1.在HuggingFists系统右上角，点击菜单“/社区版/系统升级”上传升级包hf-20250526.zip
2.进入系统，通过命令行或容器管理器界面停止容器。将docker-compose.yml文件拷贝到sengee.community.linux目录下，覆盖同名文件
3.通过命令行或容器管理器界面重启容器
4.进入系统，点击“资源库/算子库/商城”，查询Syslog，安装Syslog算子。查询Botu,安装Botu算子。查询ConsoleOut算子，升级该算子。
5.切换到“流程”菜单，选中流程组，将Syslog流程文件20250526163216.flow导入系统
6.观看视频，“https://www.bilibili.com/video/BV1zWj1zHEWB/”，了解具体使用方式